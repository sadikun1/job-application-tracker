const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/jobtracker', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const jobSchema = new mongoose.Schema({
    company: String,
    position: String,
    status: String,
    appliedDate: Date,
});

const Job = mongoose.model('Job', jobSchema);

app.get('/api/jobs', async (req, res) => {
    const jobs = await Job.find();
    res.json(jobs);
});

app.post('/api/jobs', async (req, res) => {
    const newJob = new Job(req.body);
    await newJob.save();
    res.status(201).json(newJob);
});

app.listen(5000, () => {
    console.log('Server running on port 5000');
});
