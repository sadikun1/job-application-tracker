import React, { useEffect, useState } from 'react';

function App() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/api/jobs')
      .then(res => res.json())
      .then(data => setJobs(data));
  }, []);

  return (
    <div>
      <h1>Job Applications</h1>
      <ul>
        {jobs.map((job, idx) => (
          <li key={idx}>{job.company} - {job.position} - {job.status}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
