# Job Application Tracker

A full-stack app to manage and track job applications.
